const sigEl = document.getElementById("signature");
const enEl = document.getElementById("enabled");
const statusEl = document.getElementById("status");

chrome.storage.sync.get({ enabled: true, signature: "" }, (s) => {
  sigEl.value = s.signature;
  enEl.checked = s.enabled;
});

document.getElementById("save").addEventListener("click", () => {
  chrome.storage.sync.set({ signature: sigEl.value, enabled: enEl.checked }, () => {
    statusEl.textContent = "נשמר ✓";
    setTimeout(() => (statusEl.textContent = ""), 1500);
  });
});
