// מוסיף את החתימה לסוף ההודעה רגע לפני השליחה,
// מציג אותה בתצוגה המקדימה, ומוסיף כפתור לשינוי החתימה בתוך העורך
let settings = { enabled: true, signature: "" };
const SEPARATOR = "____________________";

chrome.storage.sync.get({ enabled: true, signature: "" }, (s) => {
  settings = s;
  refreshAll();
});
chrome.storage.onChanged.addListener((changes) => {
  for (const key in changes) settings[key] = changes[key].newValue;
  refreshAll();
});

function sig() {
  return settings.enabled ? (settings.signature || "").trim() : "";
}

function appendSignature(composer) {
  const s = sig();
  if (!s) return;
  const textarea = composer.querySelector("textarea.write, textarea");
  if (!textarea) return;
  if (textarea.value.trimEnd().endsWith(s)) return; // כבר נוספה
  // קו מפריד מתווים (תמיד מוצג, לא תלוי בעיבוד Markdown) ואז החתימה
  textarea.value = textarea.value.trimEnd() + "\n\n" + SEPARATOR + "\n" + s;
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
  textarea.dispatchEvent(new Event("change", { bubbles: true }));
}

// ---------- תצוגה מקדימה ----------
function renderPreviewSig(composer) {
  const preview = composer.querySelector(".preview");
  if (!preview) return;
  let box = preview.querySelector(".mt-sig-preview");
  const s = sig();
  if (!s) {
    if (box) box.remove();
    return;
  }
  if (!box) {
    box = document.createElement("div");
    box.className = "mt-sig-preview";
    box.style.cssText = "margin-top:12px;white-space:pre-wrap;";
    preview.appendChild(box);
  } else if (box !== preview.lastElementChild) {
    preview.appendChild(box);
  }
  const text = SEPARATOR + "\n" + s;
  if (box.textContent !== text) box.textContent = text;
}

// ---------- כפתור שינוי חתימה ----------
function addEditButton(composer) {
  if (composer.querySelector(".mt-sig-btn")) return;
  // יש שני כפתורי "ביטול" (נייד ומחשב) - לוקחים את זה של המחשב
  const discard =
    composer.querySelector(".composer-discard.btn-link") ||
    [...composer.querySelectorAll(".composer-discard")].pop();

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "btn btn-sm btn-link text-body fw-semibold mt-sig-btn";
  btn.textContent = "✎ חתימה";
  btn.title = "שינוי טקסט החתימה";

  const panel = document.createElement("div");
  panel.className = "mt-sig-panel";
  panel.style.cssText = "display:none;position:fixed;z-index:2147483647;background:#fff;border:1px solid #ccc;border-radius:6px;padding:8px;box-shadow:0 4px 12px rgba(0,0,0,.2);width:320px;direction:rtl;";
  panel.innerHTML =
    '<label style="display:block;margin-bottom:6px;cursor:pointer"><input type="checkbox" class="mt-sig-en"> הפעל חתימה</label>' +
    '<textarea class="mt-sig-text" style="width:100%;height:100px;box-sizing:border-box;font-size:14px"></textarea>' +
    '<div style="margin-top:6px;text-align:left">' +
    '<button type="button" class="btn btn-sm btn-primary mt-sig-save">שמור</button> ' +
    '<button type="button" class="btn btn-sm btn-light mt-sig-close">סגור</button></div>';

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (panel.style.display === "none") {
      panel.querySelector(".mt-sig-text").value = settings.signature || "";
      panel.querySelector(".mt-sig-en").checked = settings.enabled;
      const r = btn.getBoundingClientRect();
      // העורך נמצא בתחתית המסך - פותחים את החלון מעל הכפתור
      panel.style.bottom = window.innerHeight - r.top + 4 + "px";
      panel.style.left = Math.max(8, Math.min(r.left, window.innerWidth - 340)) + "px";
      panel.style.display = "block";
    } else {
      panel.style.display = "none";
    }
  });
  panel.querySelector(".mt-sig-close").addEventListener("click", () => (panel.style.display = "none"));
  panel.querySelector(".mt-sig-save").addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    const data = {
      signature: panel.querySelector(".mt-sig-text").value,
      enabled: panel.querySelector(".mt-sig-en").checked,
    };
    settings = data;
    refreshAll();
    try {
      chrome.storage.sync.set(data);
    } catch (err) {
      alert("התוסף עודכן - צריך לרענן את הדף (F5) כדי לשמור");
      return;
    }
    panel.style.display = "none";
  });

  if (discard) discard.parentNode.insertBefore(btn, discard);
  else composer.prepend(btn);
  document.body.appendChild(panel);

  // לסגור את הפאנל כשהעורך נסגר
  const obs = new MutationObserver(() => {
    if (!document.body.contains(composer)) {
      panel.remove();
      obs.disconnect();
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });
}

function setupComposer(composer) {
  addEditButton(composer);
  renderPreviewSig(composer);
}

function refreshAll() {
  document.querySelectorAll(".composer").forEach(setupComposer);
}

// מעקב אחרי פתיחת עורך ועדכוני התצוגה המקדימה
let pending = false;
new MutationObserver(() => {
  if (pending) return;
  pending = true;
  requestAnimationFrame(() => {
    pending = false;
    refreshAll();
  });
}).observe(document.body, { childList: true, subtree: true });

// לחיצה על כפתור שליחה
document.addEventListener(
  "click",
  (e) => {
    const btn = e.target.closest(".composer-submit, [data-action='post']");
    if (!btn) return;
    const composer = btn.closest(".composer") || document.querySelector(".composer");
    if (composer) appendSignature(composer);
  },
  true
);

// שליחה עם Ctrl+Enter
document.addEventListener(
  "keydown",
  (e) => {
    if (e.key !== "Enter" || !(e.ctrlKey || e.metaKey)) return;
    const composer = e.target.closest && e.target.closest(".composer");
    if (composer) appendSignature(composer);
  },
  true
);
